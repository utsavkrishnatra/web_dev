export const SET_SKIN ="SET_SKIN";
export const UPDATE_SKIN ="UPDATE_SKIN";
